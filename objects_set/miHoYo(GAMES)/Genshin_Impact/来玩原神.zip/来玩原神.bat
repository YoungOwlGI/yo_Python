@echo off  
start ./dist/index/index.exe